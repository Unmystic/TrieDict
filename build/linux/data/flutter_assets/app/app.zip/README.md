# TrieDict
Simple python Trie adaptation. Several features currently are WIP
